/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to AL_EXT_FLOAT32 extension. */
public final class EXTFloat32 {

	/** AL_EXT_FLOAT32 tokens. */
	public static final int
		AL_FORMAT_MONO_FLOAT32   = 0x10010,
		AL_FORMAT_STEREO_FLOAT32 = 0x10011;

	private EXTFloat32() {}

}